#include <iostream>
using namespace std;

// Create a program that will accept 4 numbers and will output the numbers sorted

int main(int argc, char** argv) {
	
	int q1, q2, q3, q4;
	
	cout << " Enter first value: ";
	cin >> q1;
	
	cout << "\n Enter second value: ";
	cin >> q2;
	
	cout << "\n Enter third value: ";
	cin >> q3;
	
	cout << "\n Enter fourth value: ";
	cin >> q4;
	
	if ( q1 > q2 && q2 > q3 && q3 > q4 ){
	
	
		cout << q1 << " " << q2 << " " << q3 << " " << q4;
	}
	else if ( q2 > q1 && q1 > q3 && q3 > q4 ){
	
		cout << q2 << " " << q1 << " " << q3 << " " << q4;
	}
	else if ( q3 > q1 && q3 > q2 && q3 > q4 ){
		
		cout << q3 << " " << q1 << " " << q2 << " " << q4;
		
	}
	
	else if ( q4 > q1 && q4 > q2 && q4 > q3 ){
		
		cout << q4 << " " << q1 << " " << q2 << " " << q3;
	}
	
	return 0;
	
}	
	
