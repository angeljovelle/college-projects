#include <iostream>
using namespace std;

// Create a program that will accept 4 numbers and will output the highest among the 4 inputs.

int main(int argc, char** argv) {
	
	int q1, q2, q3, q4;
	
	cout << " Enter first value: ";
	cin >> q1;
	
	cout << "\n Enter second value: ";
	cin >> q2;
	
	cout << "\n Enter third value: ";
	cin >> q3;
	
	cout << "\n Enter fourth value: ";
	cin >> q4;
	
	if ( q1 > q2 && q1 > q3 && q1 > q4 ){
		
		cout << "The highest number is: " << q1;
	
	}
	
	else if ( q2 > q1 && q2 > q3 && q2 > q4 ){
		
		cout << "The highest number is: " << q2;
		
	}
	
	else if  ( q3 > q1 && q3 > q2 && q3 > q4 ){
		
		cout << "The highest number is: " << q3;
		
	}
	
	else if ( q4 > q1 && q4 > q2 && q4 > q3 ){
		
		cout << "The highest number is: " << q4;
		
	}
		
	return 0;
	
	}
	
