#include <iostream>
#include <cstdlib>
using namespace std;

//Sample run: 4 length, type 1 and 2

 int main(){	
  		
   int n=0,ctr=1,t=0;

   cout << "Enter length: ";
   cin >> n;
   
   cout << "Enter type (1-filled 2-nonfilled): ";
   cin >> t;
   
   cout << "\n****";
   while(ctr<=n)
   {

   	if(t==1)
   	{
   		cout << "\n****"; 
   		ctr = ctr + 2;
	}
	else if(t==2)
	{
		cout << "\n*  *";
		ctr = ctr + 2;
	} 
   	ctr++;
   }
   cout << "\n****";
  return 0;  
  
 }

