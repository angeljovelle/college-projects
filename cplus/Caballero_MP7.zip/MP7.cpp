#include <iostream>
#include <cstdlib>
#include <string>
using namespace std;

int main(){
	
	
int  MTEG, FEG, FPG, FG;
	string conv, desc, passorfail;
	
	MTEG=100;
	FEG=98;
	FPG=96;
	FG=(MTEG*0.3)+(FEG*0.4)+(FPG*0.3);
	
if (FG>= 96 && FG<=100){
	
	conv="4.0";
	desc="A High Distinction";
	passorfail=" Congrats!";
	}
	
else if(FG>=90 && FG<=95){

	conv="3.5";
	desc="B+ Distinction";
	passorfail=" Congrats!";
	
	}
	
else if(FG>=85 && FG<=89){

	conv="3.0";
	desc="B- Very Good";
	passorfail=" Congrats!";
}

else if(FG>=80 && FG<=84){

	conv="2.5";
	desc="C+ Good";
	passorfail=" Congrats!";
}

else if(FG>=75 && FG<=79){

	conv="2.0";
	desc="C- Average";
	passorfail=" Congrats!";
	
}

else if(FG<=75){

	conv="1.0";
	desc="F Fail";
	passorfail=" Sorry!";
}
	cout << FG << " " << conv << " " << desc << passorfail;
	
return 0;
	
}

