#include <iostream>
#include <string>
using namespace std;

int main(){
	
   float fahr, value;
   char temp, celc, fahrenheit;
   
   
// Sample run: Select type of conversion: 1-Mass 2-Length 3-Temp: 3 
// Select temp source unit 1-Celsius 2-Kelvin 3-Fahreheit: 1
// Enter value to be converted: 20
// Select temp destination unit 1-Celsius 2-Kelvin 3-Fahreheit: 3
// Result: 20 Celsius is eq to 68 Fahreheit!


   cout << "Select type of conversion: 1-Mass 2-Length 3-Temp: ";
   cin >> temp;
   cout << "Select temp source unit 1-Celsius 2-Kelvin 3-Fahreheit: ";
   cin >> celc;
   cout << "Enter value to be converted: ";
   cin >> value;
   cout << "Select temp destination unit 1-Celsius 2-Kelvin 3-Fahreheit: :";
   cin >> fahrenheit;

   if (temp == '3'|| fahrenheit == 3) {
   	
        fahr = (value * 1.8) + 32;
      cout << value << " Celsius is eq to" << fahr << " Fahreinheit!";
   }
  
   else
      cout << "Error, Invalid Input";

   return 0;
}
