isLoggedIn = sessionStorage.getItem('loggedIn')
        if(!isLoggedIn){
            window.location.href = "login.html";
        }

        function redirectToProductPage(productName) {
            const productPageUrl = "ProductPage.html";
            window.location.href = `${productPageUrl}?name=${productName}`;
        }
    
        let productItems = JSON.parse(localStorage.getItem("productItems"));
        
        function displayUsername() {
            const usernameDiv = document.getElementById("username");
            const username = sessionStorage.getItem('activeUsername');
            usernameDiv.textContent = username;
        }

        if (!productItems) {
            productItems = [
                { 
                    productName: "Persona 5 Royal",
                    description: "This is the description for Persona 5 Royal",
                    price: 100.00,
                    image: "img/product_1.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 4 Golden",
                    description: "This is the description for Persona 4 Golden",
                    price: 150.00,
                    image: "img/product_2.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 3 Reload",
                    description: "This is the description for Persona 3 Reload",
                    price: 300.00,
                    image: "img/product_3.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 4 Arena Ultimax",
                    description: "This is the description for Persona 4 Arena Ultimax",
                    price: 250.00,
                    image: "img/product_4.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 5 Strikers",
                    description: "This is the description for Persona 5 Strikers",
                    price: 150.00,
                    image: "img/product_5.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 5 Tactica",
                    description: "This is the description for Persona 5 Tactica",
                    price: 150.00,
                    image: "img/product_6.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona 2 Innocent Sin",
                    description: "This is the description for Persona 2 Innocent Sin",
                    price: 20.00,
                    image: "img/product_7.jpg",
                    site: "#"
                },
                { 
                    productName: "Shin Megami Tensei V",
                    description: "This is the description for Shin Megami Tensei V",
                    price: 12.00,
                    image: "img/product_8.jpg",
                    site: "#"
                },
                { 
                    productName: "Persona Q2 New Cinema Labyrinth",
                    description: "This is the description for Persona Q2 New Cinema Labyrinth",
                    price: 100.00,
                    image: "img/product_9.jpg",
                    site: "#"
                }
            ];
            localStorage.setItem("productItems", JSON.stringify(productItems));
        }
    
        window.onload = function() {
        displayUsername();    
        const searchForm = document.getElementById('searchForm');
        const searchInput = document.getElementById('searchInput');

        searchForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const searchTerm = searchInput.value.trim().toLowerCase();

            const matchedProduct = productItems.find(product => product.productName.toLowerCase() === searchTerm);

            if (matchedProduct) {
                redirectToProductPage(matchedProduct.productName);
            } else {
                alert('Display Product Not Found');
            }
        });

            const productSelectionDiv = document.querySelector(".product-selection");
    
            productItems.forEach(product => {
                const productItem = document.createElement("div");
                productItem.classList.add("product-item");
    
                const prodImg = document.createElement("div");
                prodImg.classList.add("prod_img");
                prodImg.innerHTML = `<img src="${product.image}" alt="${product.productName}">`;
    
                const productInfo = document.createElement("div");
                productInfo.classList.add("product-info");
                productInfo.innerHTML = `
                    <div>
                        <div class="name-price">
                            <h4><a href="#" onclick="redirectToProductPage('${product.productName}'); return false;">${product.productName}</a></h4>
                            <p>${product.price.toFixed(2)} PESOS</p>
                        </div>
                        <p>${product.description}</p>
                    </div>
                `;
    
                const addToCartBtn = document.createElement("button");
                addToCartBtn.type = "button";
                addToCartBtn.classList.add("add-to-cart-btn");
                addToCartBtn.textContent = "ADD TO CART";
                addToCartBtn.addEventListener("click", function() {
                    addToCart(product);
                });
    
                productItem.appendChild(prodImg);
                productItem.appendChild(productInfo);
                productItem.appendChild(addToCartBtn);
    
                productSelectionDiv.appendChild(productItem);
            });
        };

        function addToCart(product) {
        let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];

        const productObject = {
            name: product.productName,
            price: product.price,
        };

        cartItems.push(productObject);

        sessionStorage.setItem('cartItems', JSON.stringify(cartItems));

        alert(`${product.productName} added to cart.`);
        }   
        window.addEventListener('DOMContentLoaded', function() {
            document.getElementById('cartButton').addEventListener('click', function() {
                window.location.href = 'cart.html';
            });
        });