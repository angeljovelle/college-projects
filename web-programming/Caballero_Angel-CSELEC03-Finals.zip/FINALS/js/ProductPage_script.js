let productItems = JSON.parse(localStorage.getItem("productItems"));

            function displayUsername() {
                const usernameDiv = document.getElementById("username");
                const username = sessionStorage.getItem('activeUsername');
                usernameDiv.textContent = username;
            }

            function redirectToProductPage(productName) {
                const productPageUrl = "ProductPage.html";
                window.location.href = `${productPageUrl}?name=${productName}`;
            }

            window.onload = function() {
                displayUsername();   
                var productChoice = window.location.href.split("name=").reverse()[0]

                productChoice = decodeURI(productChoice)
                
                const productPage = document.querySelector(".product-wrapper");
                
                searchForm.addEventListener('submit', function(event) {
                    event.preventDefault();
        
                    const searchTerm = searchInput.value.trim().toLowerCase();
        
                    const matchedProduct = productItems.find(product => product.productName.toLowerCase() === searchTerm);
        
                    if (matchedProduct) {
                        redirectToProductPage(matchedProduct.productName);
                    } else {
                        alert('Display Product Not Found');
                    }
                });

                productItems.forEach(product => {
                    console.log(product.productName)
                    if(productChoice == product.productName){        
                        document.getElementById("product-name").innerText = `${product.productName}`;
                        const prodImg = document.createElement("div");
                        prodImg.classList.add("choice_img");
                        productPage.appendChild(prodImg)
                        
                        const Thumbnail = document.querySelector(".choice_img");
                        const imageDiv = document.createElement("div");   
                        imageDiv.classList.add("thumbnail")
                        Thumbnail.appendChild(imageDiv)

                        const descriptionDiv = document.createElement("div")
                        descriptionDiv.classList.add("productDetails")
                        descriptionDiv.innerHTML = `
                            <h2>${product.productName}</h2>
                            <p>${product.description}</p>
                        `

                        const priceDiv = document.createElement("div")
                        priceDiv.classList.add("pricing")
                        priceDiv.innerHTML = `
                            <p>${product.price.toFixed(2)} PESOS</p>
                        `
                        productPage.appendChild(descriptionDiv)
                        descriptionDiv.appendChild(priceDiv)

                        imageDiv.innerHTML = `<img src="${product.image}" alt="${product.productName}">`;

                        const addToCartBtn = document.createElement("button");
                        addToCartBtn.type = "button";
                        addToCartBtn.classList.add("add-to-cart-btn");
                        addToCartBtn.textContent = "ADD TO CART";
                        addToCartBtn.addEventListener("click", function() {
                            addToCart(product);
                        });

                        priceDiv.appendChild(addToCartBtn);

                        document.getElementById("missing-product").style.display = "none";
                        document.getElementById("product-page").style.display = "inline";
                    }
                });
                
            }

            function addToCart(product) {
            let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];

            const productObject = {
                name: product.productName,
                price: product.price,
            };

            cartItems.push(productObject);

            sessionStorage.setItem('cartItems', JSON.stringify(cartItems));

            alert(`${product.productName} added to cart.`);
            }

            window.addEventListener('DOMContentLoaded', function() {
                        document.getElementById('cartButton').addEventListener('click', function() {
                            window.location.href = 'cart.html';
                        });
                    });