let productItems = JSON.parse(localStorage.getItem("productItems"));

function displayUsername() {
    const usernameDiv = document.getElementById("username");
    const username = sessionStorage.getItem('activeUsername');
    usernameDiv.textContent = username;
}

window.onload = function(){
    displayUsername();  

const recipientName = sessionStorage.getItem('firstName') + ' ' + sessionStorage.getItem('lastName');
const shippingAddress = sessionStorage.getItem('shippingAddress');
const contactNumber = sessionStorage.getItem('contactNumber');
const itemList = JSON.parse(sessionStorage.getItem('cartItems')) || [];
const totalItems = itemList.length;
let totalPrice = 0;

document.getElementById('recipientName').innerText = recipientName;
document.getElementById('shippingAddress').innerText = shippingAddress;
document.getElementById('contactNumber').innerText = contactNumber;

const itemListElement = document.getElementById('itemList');
itemList.forEach(item => {
    const listItem = document.createElement('li');
    listItem.innerText = `${item.name}: $${item.price.toFixed(2)}`;
    itemListElement.appendChild(listItem);
    totalPrice += item.price;
});

document.getElementById('totalItems').innerText = totalItems;
document.getElementById('totalPrice').innerText = `$${totalPrice.toFixed(2)}`;

sessionStorage.removeItem('cartItems');
}





function backToHome() {
    window.location.href = 'index.html';
}


