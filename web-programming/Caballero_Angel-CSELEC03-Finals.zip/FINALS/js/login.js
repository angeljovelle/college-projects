document.addEventListener("DOMContentLoaded", () => {
    function saveSession(key, value) {
        sessionStorage.setItem(key, value);
    }

    function loadSession(key) {
        return sessionStorage.getItem(key);
    }

    function removeSession(key) {
        sessionStorage.removeItem(key);
    }
    const loginForm = document.getElementById("login-form");
    const signupForm = document.getElementById("signup-form");
    const errorMessage = document.getElementById("error-message");
    const usernameInput = document.getElementById("username");
    const passwordInput = document.getElementById("password");

    // Add event listeners for user interactions
    document.getElementById("login-btn").addEventListener("click", () => {
        if (usernameInput.value === "CSELEC03" && passwordInput.value === "webprog") {
            saveSession("username", usernameInput.value);
            saveSession("password", passwordInput.value);
            window.location.assign("index.html");
            sessionStorage.setItem('isLoggedIn', true);
        } else {
            errorMessage.classList.remove("hidden");
        }
    });

    document.getElementById("signup-btn").addEventListener("click", () => {
        loginForm.classList.add("hidden");
        signupForm.classList.remove("hidden");
    });

    document.getElementById("cancel-signup").addEventListener("click", () => {
        signupForm.classList.add("hidden");
        loginForm.classList.remove("hidden");
    });

    document.getElementById("save-signup").addEventListener("click", () => {
        if (loadSession("username") !== "CSELEC03") {
            saveSession("username", document.getElementById("signup-username").value);
            saveSession("password", document.getElementById("signup-password").value);
            signupForm.classList.add("hidden");
            loginForm.classList.remove("hidden");
        }
    });

    usernameInput.value = loadSession("username");
    passwordInput.value = loadSession("password");
  });