function redirectToProductPage(productName) {
    const productPageUrl = "ProductPage.html";
    window.location.href = `${productPageUrl}?name=${productName}`;
}

function displayUsername() {
    const usernameDiv = document.getElementById("username");
    const username = sessionStorage.getItem('activeUsername');
    usernameDiv.textContent = username;
}

window.onload = function(){
    displayUsername();  

    searchForm.addEventListener('submit', function(event) {
                    event.preventDefault();
        
                    const searchTerm = searchInput.value.trim().toLowerCase();
        
                    const matchedProduct = productItems.find(product => product.productName.toLowerCase() === searchTerm);
        
                    if (matchedProduct) {
                        redirectToProductPage(matchedProduct.productName);
                    } else {
                        alert('Display Product Not Found');
                    }
                });
}

document.addEventListener('DOMContentLoaded', function() {
    let cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];

    let compareItems = JSON.parse(localStorage.getItem("productItems"));

    const cartItemsContainer = document.getElementById('cartItemsContainer');

    function displayCartItems() {
        cartItemsContainer.innerHTML = '';

        cartItems.forEach(item => {
            compareItems.forEach(comparison => {
                if(item.name==comparison.productName){
                    const itemElement = document.createElement('div');
                    itemElement.classList.add('cart-item');
                    itemElement.innerHTML = `
                        <div class="item-details"> <!-- Container for item details -->
                            <input type="checkbox" class="itemCheckbox">
                            <img src="${comparison.image}" alt="${item.name}">
                            <p>${item.name}</p>
                        </div>
                        <p class="price">${item.price.toFixed(2)}</p> <!-- Separate container for price -->
                    `;
                    cartItemsContainer.appendChild(itemElement);
                }
            })
        });
        
    }

    displayCartItems();

    document.getElementById('deleteSelectedBtn').addEventListener('click', function() {
        const selectedCheckboxes = document.querySelectorAll('.itemCheckbox:checked');
        var i = 0;
        selectedCheckboxes.forEach(checkbox => {
            if(checkbox.checked){
                const itemDiv = checkbox.parentNode.parentNode;
                itemDiv.parentNode.removeChild(itemDiv);
                (sessionStorage.getItem("cartItems"));
                console.log(i)
                delete cartItems[i]
                sessionStorage.setItem("cartItems",JSON.stringify(cartItems))
                
            }
            i++
        });
    });

    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    selectAllCheckbox.addEventListener('change', function() {
        const checkboxes = document.querySelectorAll('.itemCheckbox');
        checkboxes.forEach(checkbox => {
            checkbox.checked = selectAllCheckbox.checked;
        });
    });

    const itemCheckboxes = document.querySelectorAll('.itemCheckbox');
    itemCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const allChecked = Array.from(itemCheckboxes).every(checkbox => checkbox.checked);
            selectAllCheckbox.checked = allChecked;
        });
    });
});