let productItems = JSON.parse(localStorage.getItem("productItems"));

function displayUsername() {
    const usernameDiv = document.getElementById("username");
    const username = sessionStorage.getItem('activeUsername');
    usernameDiv.textContent = username;
}

window.onload = function(){
    displayUsername();  

    document.getElementById('order-form').addEventListener('submit', function(event) {
        event.preventDefault();
    
        const firstName = document.getElementById('firstName').value;
        const lastName = document.getElementById('lastName').value;
        const shippingAddress = document.getElementById('address').value;
        const contactNumber = document.getElementById('contactNumber').value;
    
        sessionStorage.setItem('firstName', firstName);
        sessionStorage.setItem('lastName', lastName);
        sessionStorage.setItem('shippingAddress', shippingAddress);
        sessionStorage.setItem('contactNumber', contactNumber);
    
        window.location.href = 'orderconfirm.html';
    });
    
    function cancelOrder() {
        document.getElementById('firstName').value = '';
        document.getElementById('lastName').value = '';
        document.getElementById('address').value = '';
        document.getElementById('contactNumber').value = '';
    
        window.location.href = 'index.html';
    }
    
    displayCartSummary();
    
    document.getElementById('placeOrderBtn').addEventListener('click', function() {
        window.location.href = 'orderconfirm.html';
    });
}

function displayCartSummary() {
    const cartItems = JSON.parse(sessionStorage.getItem('cartItems')) || [];
    let total = 0;
    const cartSummaryElement = document.getElementById('cart-summary');
    
    let compareItems = JSON.parse(localStorage.getItem("productItems"));
    
    cartItems.forEach(item => {
            compareItems.forEach(comparison => {
                if(item.name==comparison.productName){
                    cartSummaryElement.innerHTML += `
                        <div>
                            <img src="${comparison.image}" alt="${item.name}" style="width: 200px; height: auto;">
                            <p>${item.name}</p>
                            <p>$${item.price.toFixed(2)}</p>
                        </div>
                    `;
                    total += item.price;
                }
            })
        });


    cartSummaryElement.innerHTML += `
        <p>Total: $${total.toFixed(2)}</p>
        <p>Number of Items: ${cartItems.length}</p>
    `;
}

//customer details

