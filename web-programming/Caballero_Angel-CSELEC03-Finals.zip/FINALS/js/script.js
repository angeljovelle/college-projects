const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');

// Use event delegation to listen for submit events on both forms
document.body.addEventListener('submit', function (event) {
    const form = event.target;
    if (form === loginForm) {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (username === 'CSELEC03' && password === 'webprog') {
            sessionStorage.setItem('loggedIn', 'true');
            sessionStorage.setItem('activeUsername', username);
            window.location.href = 'index.html';
            } 

        // Check if the username and password match the hardcoded values
        else if (sessionStorage.getItem('usernames') && sessionStorage.getItem('usernames').includes(username) && password === password) {
            sessionStorage.setItem('loggedIn', 'true');
            sessionStorage.setItem('activeUsername', username);
            window.location.href = 'index.html';
        } else {
            displayError('You have entered your password or username incorrectly. Please check your password and username and try again.');
        }
    } else if (form === signupForm) {
        event.preventDefault();

        // Validate the new username and password
        const newUsername = document.getElementById('newUsername').value.trim();
        const newPassword = document.getElementById('newPassword').value;
        if (newUsername.length < 3 || newUsername.length > 30) {
            displayError('Username must be between 3 and 30 characters long.');
            return;
        }
        const existingUsernames = JSON.parse(sessionStorage.getItem('usernames')) || [];
        if (existingUsernames.includes(newUsername)) {
            displayError('Username already exists!');
            return;
        }

        // Save the new username to the session storage, set loggedIn to false, and redirect to the login page
        existingUsernames.push(newUsername);
        sessionStorage.setItem('usernames', JSON.stringify(existingUsernames));
        sessionStorage.setItem('loggedIn', 'false');
        sessionStorage.setItem('activeUsername', newUsername);
        window.location.href = 'login.html';
    }
});

// Use a separate function to display error messages
function displayError(message) {
    document.getElementById('error').style.display = 'block';
    document.getElementById('error').textContent = message;
}